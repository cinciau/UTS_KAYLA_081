import java.util.ArrayList;
import java.util.List;

/**
 * Kelas Perusahaan menyimpan dan mengelola seluruh data karyawan.
 * Menyediakan operasi tambah, hapus, ubah posisi, ubah gaji,
 * serta pencarian dan penampilan data karyawan.
 */
public class Perusahaan {
    private List<Karyawan> daftarKaryawan;

    public Perusahaan() {
        daftarKaryawan = new ArrayList<>();
    }

    /**
     * Mencari karyawan berdasarkan ID.
     * Mengembalikan objek Karyawan jika ditemukan, atau null jika tidak ada.
     */
    public Karyawan cariKaryawanById(String id) {
        for (Karyawan k : daftarKaryawan) {
            if (k.getId().equals(id)) {
                return k;
            }
        }
        return null;
    }

    /**
     * Menambahkan karyawan baru ke dalam daftar.
     * Validasi: ID tidak boleh duplikat, gaji tidak boleh negatif.
     */
    public boolean tambahKaryawan(String id, String nama, String posisi, double gaji) {
        if (cariKaryawanById(id) != null) {
            System.out.println("ID karyawan sudah digunakan, gunakan ID lain.");
            return false;
        }
        if (gaji < 0) {
            System.out.println("Gaji tidak boleh negatif.");
            return false;
        }

        daftarKaryawan.add(new Karyawan(id, nama, posisi, gaji));
        System.out.println("Karyawan berhasil ditambahkan.");
        return true;
    }

    /**
     * Menghapus karyawan berdasarkan ID.
     * Validasi: ID harus sudah ada di daftar.
     */
    public boolean hapusKaryawan(String id) {
        Karyawan k = cariKaryawanById(id);
        if (k == null) {
            System.out.println("Karyawan dengan ID tersebut tidak ditemukan.");
            return false;
        }

        daftarKaryawan.remove(k);
        System.out.println("Karyawan berhasil dihapus.");
        return true;
    }

    /**
     * Mengubah posisi karyawan berdasarkan ID.
     * Validasi: ID harus sudah ada di daftar.
     */
    public boolean ubahPosisi(String id, String posisiBaru) {
        Karyawan k = cariKaryawanById(id);
        if (k == null) {
            System.out.println("Karyawan dengan ID tersebut tidak ditemukan.");
            return false;
        }

        k.setPosisi(posisiBaru);
        System.out.println("Posisi berhasil diubah.");
        return true;
    }

    /**
     * Mengubah gaji karyawan berdasarkan ID.
     * Validasi: ID harus sudah ada di daftar, dan gaji baru tidak boleh negatif.
     */
    public boolean ubahGaji(String id, double gajiBaru) {
        Karyawan k = cariKaryawanById(id);
        if (k == null) {
            System.out.println("Karyawan dengan ID tersebut tidak ditemukan.");
            return false;
        }
        if (gajiBaru < 0) {
            System.out.println("Gaji tidak boleh negatif.");
            return false;
        }

        k.setGaji(gajiBaru);
        System.out.println("Gaji berhasil diubah.");
        return true;
    }

    // Menampilkan seluruh data karyawan yang tersimpan
    public void tampilkanSemuaKaryawan() {
        if (daftarKaryawan.isEmpty()) {
            System.out.println("Belum ada data karyawan.");
            return;
        }

        for (Karyawan k : daftarKaryawan) {
            System.out.println(k.toString());
        }
    }
}
