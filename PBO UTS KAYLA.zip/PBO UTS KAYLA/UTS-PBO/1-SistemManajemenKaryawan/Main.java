import java.util.Scanner;

/**
 * Kelas Main menjalankan program Sistem Manajemen Karyawan.
 * Menampilkan menu pilihan kepada pengguna dan memproses input
 * untuk menambah, menghapus, mengubah, dan menampilkan data karyawan.
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Perusahaan perusahaan = new Perusahaan();
        int pilihan = 0;

        do {
            // Menampilkan menu utama
            System.out.println("=== SISTEM MANAJEMEN KARYAWAN ===");
            System.out.println("1. Tambah Karyawan");
            System.out.println("2. Hapus Karyawan");
            System.out.println("3. Ubah Posisi");
            System.out.println("4. Ubah Gaji");
            System.out.println("5. Tampilkan Semua Karyawan");
            System.out.println("6. Keluar");
            System.out.print("Masukkan pilihan: ");

            try {
                pilihan = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Input tidak valid, masukkan angka menu.");
                System.out.println();
                continue;
            }

            switch (pilihan) {
                case 1: // Tambah karyawan baru
                    System.out.print("Masukkan ID: ");
                    String id = scanner.nextLine().trim();
                    System.out.print("Masukkan Nama: ");
                    String nama = scanner.nextLine().trim();
                    System.out.print("Masukkan Posisi: ");
                    String posisi = scanner.nextLine().trim();
                    System.out.print("Masukkan Gaji: ");
                    double gaji = bacaDouble(scanner.nextLine().trim());
                    perusahaan.tambahKaryawan(id, nama, posisi, gaji);
                    break;

                case 2: // Hapus karyawan berdasarkan ID
                    System.out.print("Masukkan ID karyawan yang akan dihapus: ");
                    String idHapus = scanner.nextLine().trim();
                    perusahaan.hapusKaryawan(idHapus);
                    break;

                case 3: // Ubah posisi karyawan
                    System.out.print("Masukkan ID karyawan: ");
                    String idPosisi = scanner.nextLine().trim();
                    System.out.print("Masukkan posisi baru: ");
                    String posisiBaru = scanner.nextLine().trim();
                    perusahaan.ubahPosisi(idPosisi, posisiBaru);
                    break;

                case 4: // Ubah gaji karyawan
                    System.out.print("Masukkan ID karyawan: ");
                    String idGaji = scanner.nextLine().trim();
                    System.out.print("Masukkan gaji baru: ");
                    double gajiBaru = bacaDouble(scanner.nextLine().trim());
                    perusahaan.ubahGaji(idGaji, gajiBaru);
                    break;

                case 5: // Tampilkan semua data karyawan
                    perusahaan.tampilkanSemuaKaryawan();
                    break;

                case 6: // Keluar dari program
                    System.out.println("Terima kasih telah menggunakan sistem ini.");
                    break;

                default:
                    System.out.println("Pilihan tidak valid, silakan coba lagi.");
            }

            System.out.println();
        } while (pilihan != 6);

        scanner.close();
    }

    // Membantu membaca input gaji agar program tidak crash jika input bukan angka
    private static double bacaDouble(String input) {
        try {
            return Double.parseDouble(input);
        } catch (NumberFormatException e) {
            System.out.println("Input gaji tidak valid, dianggap 0.");
            return 0;
        }
    }
}
