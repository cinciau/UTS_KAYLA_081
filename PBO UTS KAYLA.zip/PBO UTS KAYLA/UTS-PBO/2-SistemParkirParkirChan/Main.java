import java.util.Scanner;

/**
 * Kelas Main menjalankan program Sistem Parkir ParkirChan.
 * Pengguna dapat memasukkan data kendaraan satu per satu,
 * memilih cara input durasi, lalu melihat ringkasan akhir
 * setelah semua kendaraan selesai diinput.
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int jumlahKendaraan = 0;
        double totalSemuaBiaya = 0;
        String lanjut;

        do {
            System.out.println("=== SISTEM PARKIR PARKIRCHAN ===");
            System.out.print("Masukkan jenis kendaraan (motor/mobil/truk): ");
            String jenis = scanner.nextLine().trim();

            Kendaraan kendaraan = new Kendaraan(jenis);

            // Memilih cara input durasi parkir
            System.out.println("Pilih cara input durasi parkir:");
            System.out.println("1. Input langsung jumlah jam");
            System.out.println("2. Input jam masuk dan jam keluar");
            System.out.print("Masukkan pilihan: ");
            int pilihan = bacaInt(scanner.nextLine().trim());

            double biaya;
            if (pilihan == 2) {
                System.out.print("Masukkan jam masuk: ");
                int jamMasuk = bacaInt(scanner.nextLine().trim());
                System.out.print("Masukkan jam keluar: ");
                int jamKeluar = bacaInt(scanner.nextLine().trim());
                biaya = kendaraan.hitungBiaya(jamMasuk, jamKeluar);
            } else {
                System.out.print("Masukkan durasi parkir (jam): ");
                int durasi = bacaInt(scanner.nextLine().trim());
                biaya = kendaraan.hitungBiaya(durasi);
            }

            // Menampilkan ringkasan kendaraan yang baru diinput
            System.out.println();
            System.out.println("--- Ringkasan Parkir ---");
            kendaraan.tampilkanRingkasan();

            jumlahKendaraan++;
            totalSemuaBiaya += biaya;

            System.out.println();
            System.out.print("Tambah kendaraan lagi? (y/n): ");
            lanjut = scanner.nextLine().trim();
            System.out.println();

        } while (lanjut.equalsIgnoreCase("y"));

        // Ringkasan akhir setelah semua input selesai
        System.out.println("=== Ringkasan Akhir ===");
        System.out.println("Jumlah Total Kendaraan    : " + jumlahKendaraan);
        System.out.println("Total Semua Biaya Parkir  : Rp" + totalSemuaBiaya);

        scanner.close();
    }

    // Membantu membaca input angka agar program tidak crash jika input salah
    private static int bacaInt(String input) {
        try {
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            System.out.println("Input tidak valid, dianggap 0.");
            return 0;
        }
    }
}
