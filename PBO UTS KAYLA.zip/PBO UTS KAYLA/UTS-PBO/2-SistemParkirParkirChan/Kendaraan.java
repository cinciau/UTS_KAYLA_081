/**
 * Kelas Kendaraan merepresentasikan sebuah kendaraan yang parkir.
 * Mendukung dua cara penghitungan durasi parkir (overloading method)
 * dan otomatis menghitung biaya beserta diskon jika berlaku.
 */
public class Kendaraan {
    private String jenis;        // motor, mobil, atau truk
    private int durasiParkir;    // dalam jam
    private double totalBiaya;

    // Tarif parkir per jam untuk masing-masing jenis kendaraan
    private static final double TARIF_MOTOR = 2000;
    private static final double TARIF_MOBIL = 5000;
    private static final double TARIF_TRUK = 8000;

    private static final int BATAS_JAM_DISKON = 5;
    private static final double PERSEN_DISKON = 0.10;

    // Constructor: menerima parameter jenis kendaraan
    public Kendaraan(String jenis) {
        this.jenis = jenis;
        this.durasiParkir = 0;
        this.totalBiaya = 0;
    }

    // Mengambil tarif per jam sesuai jenis kendaraan
    public double getTarifPerJam() {
        switch (jenis.toLowerCase()) {
            case "motor":
                return TARIF_MOTOR;
            case "mobil":
                return TARIF_MOBIL;
            case "truk":
                return TARIF_TRUK;
            default:
                System.out.println("Jenis kendaraan tidak dikenali, tarif dianggap 0.");
                return 0;
        }
    }

    /**
     * Overload 1: durasi parkir diinput secara manual (contoh: 2 jam).
     */
    public double hitungBiaya(int durasi) {
        this.durasiParkir = durasi;
        return prosesBiaya(durasi);
    }

    /**
     * Overload 2: durasi parkir dihitung dari jam masuk dan jam keluar.
     * Contoh: jam masuk 9, jam keluar 14 -> durasi 5 jam.
     */
    public double hitungBiaya(int jamMasuk, int jamKeluar) {
        int durasi = jamKeluar - jamMasuk;
        if (durasi < 0) {
            System.out.println("Jam keluar lebih kecil dari jam masuk, durasi dianggap 0.");
            durasi = 0;
        }
        this.durasiParkir = durasi;
        return prosesBiaya(durasi);
    }

    // Menghitung biaya parkir, lalu memberi diskon 10% jika durasi > 5 jam
    private double prosesBiaya(int durasi) {
        double biaya = durasi * getTarifPerJam();

        if (durasi > BATAS_JAM_DISKON) {
            biaya = biaya - (biaya * PERSEN_DISKON);
        }

        this.totalBiaya = biaya;
        return biaya;
    }

    public String getJenis() {
        return jenis;
    }

    public int getDurasiParkir() {
        return durasiParkir;
    }

    public double getTotalBiaya() {
        return totalBiaya;
    }

    // Menampilkan ringkasan parkir kendaraan ini
    public void tampilkanRingkasan() {
        System.out.println("Jenis Kendaraan : " + jenis);
        System.out.println("Durasi Parkir   : " + durasiParkir + " jam");
        System.out.println("Total Biaya     : Rp" + totalBiaya);
    }
}
