import java.util.Random;

/**
 * Kelas LotreBoard merepresentasikan papan permainan lotre gosok
 * berukuran 4 baris x 5 kolom dengan 2 kotak bom tersembunyi.
 */
public class LotreBoard {
    private static final int ROWS = 4;
    private static final int COLS = 5;
    private static final int JUMLAH_BOM = 2;

    private char[][] board;       // tampilan papan ke pengguna (* / O / X)
    private boolean[][] revealed; // status kotak: sudah dibuka atau belum
    private int[][] data;         // data asli kotak (0 = aman, 1 = bom)

    private int kotakAmanTerbuka; // penghitung kotak aman yang sudah dibuka

    public LotreBoard() {
        board = new char[ROWS][COLS];
        revealed = new boolean[ROWS][COLS];
        data = new int[ROWS][COLS];
        generateBoard();
    }

    // Menghasilkan papan baru: semua kotak ditutup, lalu 2 bom diletakkan secara acak
    public void generateBoard() {
        kotakAmanTerbuka = 0;

        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                board[i][j] = '*';
                revealed[i][j] = false;
                data[i][j] = 0;
            }
        }

        Random random = new Random();
        int bomDitanam = 0;
        while (bomDitanam < JUMLAH_BOM) {
            int r = random.nextInt(ROWS);
            int c = random.nextInt(COLS);
            if (data[r][c] == 0) {
                data[r][c] = 1;
                bomDitanam++;
            }
        }
    }

    // Menampilkan papan saat ini ke layar
    public void displayBoard() {
        for (int i = 0; i < ROWS; i++) {
            StringBuilder baris = new StringBuilder();
            for (int j = 0; j < COLS; j++) {
                baris.append(" ").append(board[i][j]);
            }
            System.out.println(baris.toString());
        }
    }

    /**
     * Memproses tebakan pemain pada posisi (row, col).
     * Mengembalikan false jika pemain mengenai bom, true jika aman
     * (termasuk kasus kotak yang sudah pernah dibuka sebelumnya).
     */
    public boolean guess(int row, int col) {
        if (row < 0 || row >= ROWS || col < 0 || col >= COLS) {
            System.out.println("Posisi tidak valid, coba lagi!");
            return true;
        }

        if (revealed[row][col]) {
            System.out.println("Kotak telah dibuka sebelumnya!");
            System.out.println("Kotak Aman");
            return true;
        }

        revealed[row][col] = true;

        if (data[row][col] == 1) {
            board[row][col] = 'X';
            System.out.println("BOOM! Anda menemukan bom! Permainan berakhir.");
            return false;
        } else {
            board[row][col] = 'O';
            kotakAmanTerbuka++;
            System.out.println("Kotak Aman");
            return true;
        }
    }

    // Mengecek apakah pemain sudah berhasil membuka seluruh kotak aman (menang)
    public boolean isMenang() {
        int totalAman = (ROWS * COLS) - JUMLAH_BOM;
        return kotakAmanTerbuka >= totalAman;
    }

    /**
     * Mengecek apakah permainan sudah selesai, yaitu jika ada bom yang
     * sudah terbuka, atau jika seluruh kotak aman sudah berhasil dibuka.
     */
    public boolean isGameOver() {
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                if (revealed[i][j] && data[i][j] == 1) {
                    return true;
                }
            }
        }
        return isMenang();
    }
}
