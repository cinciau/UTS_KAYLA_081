import java.util.Scanner;

/**
 * Kelas Main menjalankan permainan E-Lottery Gosok.
 * Pemain menebak posisi (baris, kolom) satu per satu sampai
 * menemukan bom (kalah) atau berhasil membuka semua kotak aman (menang).
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LotreBoard lotreBoard = new LotreBoard();
        boolean kalah = false;

        System.out.println("Welcome to E-Lottery Gosok");
        lotreBoard.displayBoard();

        while (!lotreBoard.isGameOver()) {
            System.out.println();
            System.out.print("Masukkan tebakan anda (baris dan kolom) : ");

            int baris = scanner.nextInt();
            int kolom = scanner.nextInt();

            boolean aman = lotreBoard.guess(baris, kolom);
            lotreBoard.displayBoard();

            if (!aman) {
                kalah = true;
                break;
            }
        }

        if (!kalah) {
            System.out.println();
            System.out.println("Selamat anda menang");
        } else {
            System.out.println();
            System.out.println("Permainan berakhir, coba lagi lain kali!");
        }

        scanner.close();
    }
}
